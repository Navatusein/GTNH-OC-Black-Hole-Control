local versions = {
  programVersion = "1.0.5",
  configVersion = 1
}

return versions