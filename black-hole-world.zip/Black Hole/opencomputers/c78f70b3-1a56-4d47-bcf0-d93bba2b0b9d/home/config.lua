local sides = require("sides")

local loggerLib = require("lib.logger-lib")
local discordLoggerHandler = require("lib.logger-handler.discord-logger-handler-lib")
local fileLoggerHandler = require("lib.logger-handler.file-logger-handler-lib")
local scrollListLoggerHandler = require("lib.logger-handler.scroll-list-logger-handler-lib")

local blackHoleController = require("src.black-hole-controller")

local config = {
  enableAutoUpdate = true, -- Enable auto update on start

  logger = loggerLib:newFormConfig({
    name = "Black Hole Control",
    timeZone = 3, -- Your time zone
    handlers = {
      discordLoggerHandler:newFormConfig({
        logLevel = "warning",
        messageFormat = "{Time:%d.%m.%Y %H:%M:%S} [{LogLevel}]: {Message}",
        discordWebhookUrl = "" -- Discord Webhook URL
      }),
      fileLoggerHandler:newFormConfig({
        logLevel = "info",
        messageFormat = "{Time:%d.%m.%Y %H:%M:%S} [{LogLevel}]: {Message}",
        filePath = "logs.log"
      }),
      scrollListLoggerHandler:newFormConfig({
        logLevel = "debug",
        logsListSize = 32
      }),
    }
  }),

  controller = blackHoleController:newFormConfig({
    blackHoleSeedsTransposerAddress = "3fb04902-c266-4288-afae-c4d6cd06a5a1", -- Address of the transposer which provide black hole seeds.
    blackHoleSeedInputBusSide = sides.south, -- Side of the transposer which connected to seeds input bus.
    ioPortTransposerAddress = "07551cf8-6f4d-4f6c-aede-7efa650f7cde", -- Address of the transposer which connected to ME Drive and ME IO Port.
    meDriveSide = sides.west, -- Side of the transposer which connected to ME Drive.
    meIoPortSide = sides.east, -- Side of the transposer which connected to ME IO Port.
    meInterfaceAddress = "ae27b36c-99de-42a5-9b1d-6c04a739bc6d", -- Address of ME Interface.
    saveRecipeMode = true, -- Recipe save mode.
    maxCyclesCount = 5, -- Maximum number of cycles. For calculation use: https://www.desmos.com/calculator/yrnt694v3h
  })
}

return config
